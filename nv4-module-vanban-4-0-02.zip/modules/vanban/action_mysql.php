<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */

if( !defined('NV_IS_FILE_MODULES') ) die('Stop!!!');

$sql_drop_module = array();
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "`";
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_cat`";
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_room`";
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_field`";
$sql_drop_module[] = "DROP TABLE IF EXISTS `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_organ`";

$sql_create_module = $sql_drop_module;

$sql_create_module[] = "CREATE TABLE `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,    
  `time` INT( 11 ) DEFAULT '0',
  `tomtat` mediumtext  ,
  `chitiet` mediumtext ,
  `idcat` INT( 11 ) DEFAULT '0',
  `idroom` INT( 11 ) DEFAULT '0',
  `idfield` INT( 11 ) DEFAULT '0',
  `idorgan` INT( 11 ) DEFAULT '0',
  `copyr` varchar(255),
  `file` varchar(225),
  `type` varchar(15),
  `hits` int(20) DEFAULT '0',
  `dows` int(20) DEFAULT '0',
  `active` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8";

$sql_create_module[] = "CREATE TABLE `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_cat` (
  `catid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catname` varchar(255) NOT NULL,
  `catalias` varchar(100) NOT NULL, 
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8";

$sql_create_module[] = "CREATE TABLE `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_room` (
  `roomid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `roomname` varchar(255) NOT NULL,
  `roomalias` varchar(100) NOT NULL, 
  PRIMARY KEY (`roomid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8";
$sql_create_module[] = "CREATE TABLE `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_field` (
  `fieldid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `fieldname` varchar(255) NOT NULL,
  `fieldalias` varchar(100) NOT NULL, 
  PRIMARY KEY (`fieldid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8";
$sql_create_module[] = "CREATE TABLE `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_organ` (
  `organid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `organname` varchar(255) NOT NULL,
  `organalias` varchar(100) NOT NULL, 
  PRIMARY KEY (`organid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8";

$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "` (`id`, `name`, `alias`, `time`, `tomtat`, `chitiet`, `idcat`, `idroom`, `idfield`, `idorgan`, `copyr`, `file`, `type`, `active`) VALUES (NULL, 'CVM-TH-11-2011','CV-CTV-11-2011', '123456', 'Trích yêu mẫu - các bạn nên xóa văn bản này đi', 'Nội dung chi tiết văn bản', '1', '1', '1', '1', 'NhanhGon.vn', 'http://nhanhgon.vn', 'zip', '1');";
$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_cat` (`catid` ,`catname`, `catalias` )VALUES (NULL , 'Công Văn', 'cong-van')";
$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_room` (`roomid` ,`roomname`, `roomalias`)VALUES (NULL , 'THCS','thcs')";
$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_field` (`fieldid` ,`fieldname`, `fieldalias`)VALUES (NULL , 'Giáo dục','giao-duc')";
$sql_create_module[] = "INSERT INTO `" . $db_config['prefix'] . "_" . $lang . "_" . $module_data . "_organ` (`organid` ,`organname`, `organalias`)VALUES (NULL , 'Bộ Giáo Dục','bo-giao-duc')";
?>