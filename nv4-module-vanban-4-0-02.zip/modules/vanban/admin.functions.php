<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */

if ( ! defined( 'NV_ADMIN' ) or ! defined( 'NV_MAINFILE' ) or ! defined( 'NV_IS_MODADMIN' ) ) die( 'Stop!!!' );

define( 'NV_IS_LAWS_ADMIN', true );
$submenu['add'] = "Thêm văn bản mới";
$submenu['cat'] = "Quản lý loại văn bản";
$submenu['room'] = "Quản lý phòng ban ";
$submenu['field'] = "Quản lý lĩnh vực ";
$submenu['organ'] = "Quản lý Cơ quan";
$allow_func = array( 'main','add', 'cat', 'room', 'field', 'organ', 'acti');

require_once NV_ROOTDIR . "/modules/" . $module_name . '/global.functions.php';
?>