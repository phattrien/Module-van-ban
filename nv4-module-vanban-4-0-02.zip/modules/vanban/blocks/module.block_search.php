<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */
 
global $nv_Request, $part_page, $module_name, $array_global_cat, $array_global_room, $array_global_field, $array_global_organ, $search, $lang_module;

if($search['ttime']) $search['ttime'] = nv_date('d/m/Y',$search['ttime']);
if($search['dtime']) $search['dtime'] = nv_date('d/m/Y',$search['dtime']);

$xtpl = new XTemplate("block_search.htm", NV_ROOTDIR . "/themes/" . $global_config['module_theme'] . "/modules/" . $module_name);
$xtpl->assign('LANG', $lang_module);
$xtpl->assign('ACTION', NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name."&".NV_OP_VARIABLE."=".$module_info['alias']['search'].'&s=1');

$xtpl->assign('SEARCH', $search);

if( $search['cat'] != 0 || $search['room'] != 0 || $search['field'] != 0 || $search['organ'] != 0 || $search['ttime'] != '' || $search['dtime'] != ''  ) $xtpl->assign('style', 'style="display: block"'); 

unset($array_global_cat[0]);
unset($array_global_room[0]);
unset($array_global_field[0]);
unset($array_global_organ[0]);

foreach($array_global_cat as $array_global_cat1){  
    $array_global_cat1['selected'] = ($search['cat'] == $array_global_cat1['id'])? 'selected="selected"' : '';
    $xtpl->assign('cat', $array_global_cat1);     
    $xtpl->parse('main.cat');    
}
foreach($array_global_room as $array_global_room1){ 
    $array_global_room1['selected'] = ($search['room'] == $array_global_room1['id'])? 'selected="selected"' : '';
    $xtpl->assign('room', $array_global_room1);     
    $xtpl->parse('main.room');    
}
foreach($array_global_field as $array_global_field1){  
    $array_global_field1['selected'] = ($search['field'] == $array_global_field1['id'])? 'selected="selected"' : '';
    $xtpl->assign('field', $array_global_field1);     
    $xtpl->parse('main.field');    
}
foreach($array_global_organ as $array_global_organ1){  
    $array_global_organ1['selected'] = ($search['organ'] == $array_global_organ1['id'])? 'selected="selected"' : '';
    $xtpl->assign('organ', $array_global_organ1);     
    $xtpl->parse('main.organ');    
}
$xtpl->parse('main');
$content .= $xtpl->text('main');
?>