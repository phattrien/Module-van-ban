<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */


if ( ! defined( 'NV_IS_MOD_LAWS' ) ) die( 'Stop!!!' );
if ( ! defined( 'SHADOWBOX' ) )

$array_data = array();

$page = $nv_Request->get_int('page','get',1);


if(!$nv_Request->isset_request('s','get,post')){
    header("Location: ". nv_url_rewrite(NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name,true));
}

$search = array();
$search['q'] = $nv_Request->get_title('q','get,post','');
$search['cat'] = $nv_Request->get_int('cat','get,post',0);
$search['room'] = $nv_Request->get_int('room','get,post',0);
$search['field'] = $nv_Request->get_int('field','get,post',0);
$search['organ'] = $nv_Request->get_int('organ','get,post',0);
$search['ttime'] = $nv_Request->get_title('ttime','get,post','');
$search['dtime'] = $nv_Request->get_title('dtime','get,post','');

$base_url = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name."&op=".$module_info['alias']['search'].'&s=1';

$where = "`active` = 1";
if (!empty($search['q'])) {
    $where .= " AND (`name` LIKE '%" . $search['q'] . "%' OR `tomtat` LIKE '%" . $search['q'] . "%' OR `copyr` LIKE '%" . $search['q'] . "%')";
    $base_url .= '&q='.$search['q'];
}
if ($search['cat'] > 0) {
    $where .= " AND `idcat` = " . $search['cat'];
    $base_url .=  "&cat=".$search['cat'];
}

if ($search['field'] > 0) {
    $where .= " AND `idfield` = " . $search['field'];
    $base_url .=  "&field=".$search['field'];
}
if ($search['room'] > 0) {
    $where .= " AND `idroom` = " . $search['room'];
    $base_url .=  "&room=".$search['room'];
}
if ($search['organ'] > 0) {
    $where .= " AND `idorgan` = " . $search['organ'];
    $base_url .=  "&organ=".$search['organ'];
}

$search['ttime'] = lawtime($search['ttime']);
$search['dtime'] = lawtime($search['dtime']);

if ($search['ttime'] <> "" && $search['dtime'] <> "") {
    $where .= " AND `time` >= " . $search['ttime'] . " AND `time` <= " . $search['dtime'];
    $base_url .=  "&ttime=".$search['ttime']."&dtime=".$search['dtime'];
}


$db->sqlreset()->from(NV_PREFIXLANG . "_" . $module_data)
    ->where($where); 
$db->select(" COUNT(*)") ;
$all_page = $db->query( $db->sql())->fetchColumn();   

$db->select("id, name, tomtat, idcat, idroom, idorgan, idfield, file,type, copyr, time, active, alias")
    ->order("id DESC")
    ->limit(PER_PAGE)
    ->offset( ($page-1)*PER_PAGE );
   
$array_data = $db->query( $db->sql())->fetchAll();     

$xtpl = new XTemplate("search.htm", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/" . $module_file );
$xtpl->assign('LANG', $lang_module);
$xtpl->assign('PART', NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name);
$xtpl->assign('IMGM', NV_BASE_SITEURL . "themes/" . $global_config['module_theme'] . "/images/" . $module_name);
$xtpl->assign('all_page',$all_page);

foreach($array_data as $row  ){ 
        $row['name2'] = str_replace($search['q'], '<span class="keyword">'.$search['q'].'</span>', $row['name'] );
        $row['tomtat2'] = str_replace($search['q'], '<span class="keyword">'.$search['q'].'</span>', $row['tomtat'] );
        $row['time'] = date( "d/m/Y", $row['time']);			
        $row['link'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name."&".NV_OP_VARIABLE."=".$module_info['alias']['view'].'/'.$row['alias']."-".$row['id'];
        $row['icon_ext'] = NV_BASE_SITEURL . "themes/" . $global_config['module_theme'] . "/images/" . $module_name.'/'.$row['type'].'.png';
        $xtpl->assign('ROW', $row);
		$xtpl->parse('main.loop');        
}

$list_pages = nv_generate_page( $base_url, $all_page, PER_PAGE, $page );
$xtpl->assign( 'PAGES', $list_pages );

$xtpl->parse('main');
$contents = $xtpl->text('main');

$page_title = $module_info['custom_title'];

include NV_ROOTDIR . '/includes/header.php';
echo nv_site_theme( $contents );
include NV_ROOTDIR . '/includes/footer.php';
?>