<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */
 
if (!defined('NV_IS_MOD_LAWS'))
    die('Stop!!!');
$id = $nv_Request->get_int('id','post',0);
$checks = $nv_Request->get_int('checks','post','');
$timestamp = $nv_Request->get_int($module_data . '_' . $op . '_' . $id, 'session',0);
if ( !$timestamp and $id>0 and $checks = md5($global_config['sitekey'])) {
	$nv_Request->set_Session( $module_data . '_' . $op . '_' . $id, NV_CURRENTTIME );
	$db->query("UPDATE " . NV_PREFIXLANG . "_" . $module_data . " SET dows = dows+1 WHERE `id` =" . $id);
} else {
   die('Lỗi !'); 
}
?>