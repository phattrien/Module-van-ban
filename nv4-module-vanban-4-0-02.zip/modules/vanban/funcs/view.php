<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */
 
if ( ! defined( 'NV_IS_MOD_LAWS' ) ) die( 'Stop!!!' );

$key_words = $module_info['keywords'];
$link_md = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name;

$id = intval(end(explode("-", $array_op[1])));

$xtpl = new XTemplate("view.htm", NV_ROOTDIR . "/themes/" . $global_config['module_theme'] . "/modules/" . $module_name);
$xtpl->assign('LANG', $lang_module);
$xtpl->assign('PART', NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name);
$xtpl->assign('IMGM', NV_BASE_SITEURL . "themes/" . $global_config['module_theme'] . "/images/" . $module_name);

$query = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data . "` WHERE `id` =". $id);
$row = $query->fetch();

$row['time'] = date ( "d/m/Y", $row['time']);

$row['cat'] = $array_global_cat[$row['idcat']];       
$row['room'] = $array_global_room[$row['idroom']];
$row['field'] = $array_global_field[$row['idfield']];
$row['organ'] = $array_global_organ[$row['idorgan']];
$row['icon_ext'] = NV_BASE_SITEURL . "themes/" . $global_config['module_theme'] . "/images/" . $module_name.'/'.$row['type'].'.png';
        
$xtpl->assign('ROW', $row);
if(!empty($row['chitiet'])) $xtpl->parse('main.chitiet');

if( defined( "NV_IS_ADMIN" ) ){
    $xtpl->assign('link_edit', NV_BASE_ADMINURL. "index.php?" . NV_NAME_VARIABLE . "=" . $module_name."&op=add&id=".$row['id']);
    $xtpl->parse('main.edit');
}

$xtpl->parse('main');
$contents = $xtpl->text('main');

$db->query("UPDATE `" . NV_PREFIXLANG . "_" . $module_data . "` SET hits=hits+1 WHERE `id` =".$id) or die("Erro update hits");

$page_title = $array_global_cat[$row['idcat']]['name']. ' '. $row['name'];
$array_mod_title[] = array(
        'catid' => 0,
        'title' => $array_global_cat[$row['idcat']]['name'],
        'link' => $array_global_cat[$row['idcat']]['link']);
        
include NV_ROOTDIR . '/includes/header.php';
echo nv_site_theme( $contents );
include NV_ROOTDIR . '/includes/footer.php';
?>