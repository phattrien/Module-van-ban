<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */


if ( ! defined( 'NV_IS_MOD_LAWS' ) ) die( 'Stop!!!' );
if ( ! defined( 'SHADOWBOX' ) )

$idfield = 0;
unset($array_global_field[0]);
foreach( $array_global_field as $_r ){
    if( $_r['alias'] ==  $array_op[1]){
        $idfield = $_r['id'];
    }
}


$page = 1;
if ( isset($array_op[2]) and !empty($array_op[2]))    {
    if (substr($array_op[2], 0, 5) == "page-")
    {
        $page = intval(substr($array_op[2], 5));
    }
}


$base_url = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name."&op=".$module_info['alias']['field'].'/'.$array_global_field[$idfield]['alias'];
$xtpl = new XTemplate("field.htm", NV_ROOTDIR . "/themes/" . $module_info['template'] . "/modules/" . $module_file );
$xtpl->assign('PART', NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name);
$xtpl->assign('IMGM', NV_BASE_SITEURL . "themes/" . $global_config['module_theme'] . "/images/" . $module_name);

$xtpl->assign('FIELD', $array_global_field[$idfield] );

$db->sqlreset()->from(NV_PREFIXLANG . "_" . $module_data)
    ->where("`active` = 1 and idroom=".$idfield); 
$db->select(" COUNT(*)") ;
$all_page = $db->query( $db->sql())->fetchColumn();   

$db->select("id, name, tomtat, idcat, idroom, idorgan, idfield, file, type, copyr, time, active, alias")
    ->order("id DESC")
    ->limit(PER_PAGE)
    ->offset( ($page-1)*PER_PAGE );
   
$query = $db->query( $db->sql());     

while( $row = $query->fetch() ){   
        $row['time'] = date( "d/m/Y", $row['time']);			
        $row['link'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name."&".NV_OP_VARIABLE."=".$module_info['alias']['view'].'/'.$row['alias']."-".$row['id'];
        $row['icon_ext'] = NV_BASE_SITEURL . "themes/" . $global_config['module_theme'] . "/images/" . $module_name.'/'.$row['type'].'.png';
        $xtpl->assign('ROW', $row);
		$xtpl->parse('main.loop');        
}

$list_pages = nv_alias_page($page_title, $base_url, $all_page, PER_PAGE, $page );
$xtpl->assign( 'PAGES', $list_pages );

$xtpl->parse('main');
$contents = $xtpl->text('main');

$page_title = $module_info['custom_title'];

$array_mod_title[] = array(
        'catid' => 0,
        'title' => $array_global_field[$idfield]['name'],
        'link' => $array_global_field[$idfield]['link']);
        


include NV_ROOTDIR . '/includes/header.php';
echo nv_site_theme( $contents );
include NV_ROOTDIR . '/includes/footer.php';
?>