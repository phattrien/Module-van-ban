<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */

if (! defined ( 'NV_ADMIN' ) or ! defined ( 'NV_MAINFILE' ))
	die ( 'Stop!!!' );

$module_version = array (
        "name" => "LAWS", //
        "modfuncs" => "main,view,room,cat,field,organ,search", //
        "change_alias" => "view,room,cat,field,organ",
        "submenu" => "", //
		"is_sysmod" => 0, //
		"virtual" => 1, //
		"version" => "4.0.01", //
		"date" => "Tue, 22 Nov 2011 01:52:39 GMT", //
		"author" => "NhanhGon.vn (vuqueds@gmail.com)", //
		"uploads_dir" => array($module_name), //
		"note" => "" //
	);
?>