<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */
 
if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );


$array_global_cat = $array_global_room = $array_global_field = $array_global_organ = array();
$sql = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data."_cat` ORDER BY `catid` ASC");
while( $row = $sql->fetch()){
    $array_global_cat[$row['catid']]['id'] = $row['catid'];
    $array_global_cat[$row['catid']]['name'] = $row['catname'];
    $array_global_cat[$row['catid']]['alias'] = $row['catalias'];
    $array_global_cat[$row['catid']]['link'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name.'&'.NV_OP_VARIABLE."=".$module_info['alias']['cat'].'/'.$row['catalias'];
} 
$sql = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data."_room` ORDER BY `roomid` ASC");
while( $row = $sql->fetch()){
    $array_global_room[$row['roomid']]['id'] = $row['roomid'];
    $array_global_room[$row['roomid']]['name'] = $row['roomname'];
    $array_global_room[$row['roomid']]['alias'] = $row['roomalias'];
    $array_global_room[$row['roomid']]['link'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name.'&'.NV_OP_VARIABLE."=".$module_info['alias']['room'].'/'.$row['roomalias'];
} 		
$sql = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data."_field` ORDER BY `fieldid` ASC");
while( $row = $sql->fetch()){
    $array_global_field[$row['fieldid']]['id'] = $row['fieldid'];
    $array_global_field[$row['fieldid']]['name'] = $row['fieldname'];
    $array_global_field[$row['fieldid']]['alias'] = $row['fieldalias'];
    $array_global_field[$row['fieldid']]['link'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name.'&'.NV_OP_VARIABLE."=".$module_info['alias']['field'].'/'.$row['fieldalias'];
} 
$sql = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data."_organ` ORDER BY `organid` ASC");
while( $row = $sql->fetch()){
    $array_global_organ[$row['organid']]['id'] = $row['organid'];
    $array_global_organ[$row['organid']]['name'] = $row['organname'];
    $array_global_organ[$row['organid']]['alias'] = $row['organalias'];
    $array_global_organ[$row['organid']]['link'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name.'&'.NV_OP_VARIABLE."=".$module_info['alias']['organ'].'/'.$row['organalias'];
} 

function lawtype ($file) {
    $type = pathinfo($file, PATHINFO_EXTENSION);
    return $type;
}

function lawtime ($ltime){
	unset( $m );
	if ( preg_match( "/^([0-9]{1,2})\/([0-9]{1,2})\/([0-9]{4})$/", $ltime, $m ) ){
	    $ltime = mktime( 0, 0, 0, $m[2], $m[1], $m[3] );
	}else{
	    $ltime = "";
	}
	return $ltime;
}  
?>