<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$lang_translator['author'] = "NhanhGon.vn (nhanhgon123@gmail.com)";
$lang_translator['createdate'] = "22/11/2011, 01:52";
$lang_translator['copyright'] = "@Copyright (C) NhanhGon.vn";
$lang_translator['info'] = "";
$lang_translator['langtype'] = "lang_module";

$lang_module['code'] = "Số/Ký hiệu";
$lang_module['cat'] = "Loại văn bản";
$lang_module['room'] = "Phòng ban";
$lang_module['field'] = "Lĩnh vực";
$lang_module['organ'] = "Cơ quan";
?>