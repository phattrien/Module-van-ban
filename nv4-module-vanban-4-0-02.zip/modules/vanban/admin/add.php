<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */
 
if ( ! defined( 'NV_IS_LAWS_ADMIN' ) ) die( 'Stop!!!' );
$page_title = "Cập nhật văn bản";

if ( defined( 'NV_EDITOR' ) ){
    require_once ( NV_ROOTDIR . '/' . NV_EDITORSDIR . '/' . NV_EDITOR . '/nv.php' );
}

$my_head = "<script type=\"text/javascript\" src=\"" . NV_BASE_SITEURL . "js/popcalendar/popcalendar.js\"></script>\n";
$my_head .= "<script type=\"text/javascript\" src=\"" . NV_BASE_SITEURL . "js/shadowbox/shadowbox.js\"></script>\n";
$my_head .= "<link rel=\"stylesheet\" type=\"text/css\" href=\"" . NV_BASE_SITEURL . "js/shadowbox/shadowbox.css\" />\n";
$my_head .= "<script type=\"text/javascript\">\n";
$my_head .= "Shadowbox.init({\n";
$my_head .= "});\n";
$my_head .= "</script>\n";

$id = $nv_Request->get_int('id', 'get', 0);
$get = array();
$get['name'] = $nv_Request->get_string( 'name', 'post', '' );
$get['tomtat'] = $nv_Request->get_string( 'tomtat', 'post', '' );
$get['idcat'] = $nv_Request->get_int('idcat', 'post', 0);
$get['idroom'] = $nv_Request->get_int('idroom', 'post', 0);
$get['idfield'] = $nv_Request->get_int('idfield', 'post', 0);
$get['idorgan'] = $nv_Request->get_int('idorgan', 'post', 0);
$get['chitiet'] = $nv_Request->get_editor( 'chitiet', '', NV_ALLOWED_HTML_TAGS, '' );
$get['file'] = $nv_Request->get_title( 'file', 'post', '' );
$get['copyr'] = $nv_Request->get_string( 'copyr', 'post', '' );
$get['time'] = $nv_Request->get_string( 'time', 'post', nv_date('d/m/Y', NV_CURRENTTIME ) );
$get['active'] = $nv_Request->get_int( 'active', 'post', 0 );
$get['alias'] = change_alias(nv_strtolower($get['name']));

$xtpl = new XTemplate("add.htm", NV_ROOTDIR . "/themes/" . $global_config['module_theme'] . "/modules/" . $module_name);
$xtpl->assign( 'PATH', NV_UPLOADS_DIR . "/" . $module_name);
$xtpl->assign( 'LINK_WEB', NV_BASE_SITEURL );

$xtpl->assign( 'path', NV_UPLOADS_DIR . '/' . $module_name );
$xtpl->assign( 'curentpath', NV_UPLOADS_DIR."/".$module_name );


$error = "";
$get['time2'] = lawtime($get['time']);
if ( ($nv_Request->get_int( 'add', 'post', 0 ) == 1) ){
   $get['type'] = lawtype($get['file']);
   if ( $get['name'] == "" )   {
      $error = "Bạn chưa nhập tên";
   } 
   elseif ( $get['tomtat'] == "" ){
      $error = "Bạn chưa nhập tóm tắt";
   }
   elseif($get['idcat'] == 0){
      $error = "Bạn chưa chọn loại văn bản";  
   }
   elseif($get['idroom'] == 0){
      $error = "Bạn chưa chọn phòng ban";  
   }
   elseif($get['idfield'] == 0){
      $error = "Bạn chưa chọn lĩnh vực";  
   }
   elseif($get['idorgan'] == 0){
      $error = "Bạn chưa chọn cơ quan";  
   }
   elseif ( $get['time2'] == "" ){
      $error = "Thời gian ban hành chưa hợp lý";
   }
   else{	
	   if ($id != 0){
			$query = "UPDATE `" . NV_PREFIXLANG . "_" . $module_data . "` SET 
			`name` = '".$get['name']."', `alias` = '".$get['alias']."', `time` = '".$get['time2']."',`tomtat` = '".$get['tomtat']."',
			`chitiet` = '".$get['chitiet']."', `idcat` = '".$get['idcat']."', `idroom` = '".$get['idroom']."',	`idfield` = '".$get['idfield']."',	`idorgan` = '".$get['idorgan']."',
			`copyr` = '".$get['copyr']."',`file` = '".$get['file']."',`type` = '".$get['type']."',`active` = '".$get['active']."'
            WHERE `id` = '".$id."' limit 1";
			if ( $db->query( $query ) ){ 
			 //$xxx->closeCursor();
			 Header( "Location: " . NV_BASE_ADMINURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name); die();
			} 
			else { 
			 $error = "Không thể lưu dữ liệu được"; 
			}			
		}
	   else { 
			$query ="INSERT INTO `" . NV_PREFIXLANG . "_" . $module_data . "` (
            `id`, `name`, `alias`, `time`, `tomtat`, 
            `chitiet`, `idcat`, `idroom`, `idfield`, `idorgan`, 
            `copyr`, `file`, `type`, `hits`,`dows`, `active`) VALUES (
            NULL, '". $get["name"] ."','". $get["alias"] ."', '". $get["time2"] ."', '". $get["tomtat"]."', 
            '". $get["chitiet"] ."', '". $get["idcat"] ."', '". $get["idroom"] ."', '". $get["idfield"] ."', '".  $get["idorgan"] ."', 
            '". $get["copyr"] ."', '". $get["file"] ."', '". $get["type"] ."', 0, 0, '". $get["active"] ."')"; 

			  if ( $db->insert_id( $query ) ) { 
				 //$xxx->closeCursor();
				 Header( "Location: " . NV_BASE_ADMINURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name); die("Co loi xay ra");
			  } 
			  else { 
				 $error = "Không thể lưu dữ liệu được"; 
			  } 
		}
	}
}

if ($id !=0){
    $sql = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data . "` WHERE `id` =". $id);
    while ( $row = $sql->fetch()){
        $row['time'] = date ( "d/m/Y", $row['time']);
    	$get = $row;
    }
}  

$sql = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data . "_cat` ORDER BY `catid` ASC");

while ( $row = $sql->fetch()){
    $row['selecte'] = (!empty($get['idcat']) and $row['catid'] == $get['idcat']) ? 'selected = "selected"' : '' ;
    $xtpl->assign('cat', $row);
    $xtpl->parse('main.cat');
}
 

$sql = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data . "_room` ORDER BY `roomid` ASC");

while ( $row = $sql->fetch()){
    $row['selecte'] = (!empty($get['idroom']) and $row['roomid'] == $get['idroom']) ? 'selected = "selected"' : '' ;
    $xtpl->assign('room', $row);
    $xtpl->parse('main.room');
}

$sql = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data . "_field` ORDER BY `fieldid` ASC");

while ( $row = $sql->fetch()){
    $row['selecte'] = (!empty($get['idfield']) and $row['fieldid'] == $get['idfield']) ? 'selected = "selected"' : '' ;
    $xtpl->assign('field', $row);
    $xtpl->parse('main.field');
}

$sql = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data . "_organ` ORDER BY `organid` ASC");

while ( $row = $sql->fetch()){
    $row['selecte'] = (!empty($get['idorgan']) and $row['organid'] == $get['idorgan']) ? 'selected = "selected"' : '' ;
    $xtpl->assign('organ', $row);
    $xtpl->parse('main.organ');
}
    
      
if( $error ){
    $xtpl->assign('error', $error);
    $xtpl->parse('main.loi');
}
if ( defined( 'NV_EDITOR' ) and nv_function_exists( 'nv_aleditor' ) ){
    $xtpl->assign('chitiet', nv_aleditor( "chitiet", '100%', '200px', $get['chitiet'] ));
    $xtpl->parse('main.chitiet1');
}else{
    $xtpl->parse('main.chitiet2');
}
$get['time'] = nv_date($get['time']);
$get['achecked'] = ($get['active'] == '1')? 'checked = "checked"' : '';     
$xtpl->assign('DATA', $get);        
$xtpl->parse('main');
$contents = $xtpl->text('main');

include (NV_ROOTDIR . "/includes/header.php");
echo nv_admin_theme($contents);
include (NV_ROOTDIR . "/includes/footer.php");
?>