<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */

if ( ! defined( 'NV_IS_LAWS_ADMIN' ) ) die( 'Stop!!!' );
$page_title = "Quản lý lĩnh vực";
$link_md = "index.php?" . NV_NAME_VARIABLE . "=" . $module_name."&op=field";
//xoa
$del = $nv_Request->get_int('del', 'post,get', 0);
if ( $del > 0 ){
    //if ( ! defined( 'NV_IS_AJAX' ) ) die( 'Wrong URL' );    
	$sql = "DELETE FROM `" . NV_PREFIXLANG . "_" . $module_data ."_field` WHERE `fieldid`=" . $del;
	$result = $db->query( $sql );
	nv_del_moduleCache( $module_name );
	die( "Xóa xong" );
}

$id = $nv_Request->get_int('id', 'get', 0);
$xtpl = new XTemplate("cat.htm", NV_ROOTDIR . "/themes/" . $global_config['module_theme'] . "/modules/" . $module_name);
$xtpl->assign('part', $link_md);

$sql = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data."_field` ORDER BY `fieldid` ASC");
$result = $sql->fetchAll();
foreach( $result as $row ){
    $row['id'] = $row['fieldid'];
    $row['name'] = $row['fieldname'];                               
    $xtpl->assign('ROW', $row);
    $xtpl->parse('main.loop');
} 

//them vb moi
$error = "";
$get = array();
$get['name'] = $nv_Request->get_title( 'name', 'post', '' );
$get['alias'] = strtolower(change_alias($get['name']));
if ( ($nv_Request->get_int( 'add', 'post', 0 ) == 1) ){
   if ( $get['name'] == "" ){
		$error = "Bạn chưa nhập tên";
   }else{
        if ($id != 0){
        	$query = "UPDATE `" . NV_PREFIXLANG . "_" . $module_data . "_field` SET `fieldname` ='".$get['name']."', `fieldalias` ='".$get['alias']."' WHERE `fieldid` = '".$id."' limit 1"; 
        	if ( $db->query( $query ) ){ 
        	 //$xxx->closeCursor(); 
        	 Header( "Location: " . $link_md); die();
        	}else { 
        	 $error = "Không thể cập nhật liệu được"; 
        	}	
        }else {
        	$query = "INSERT INTO `" . NV_PREFIXLANG . "_" . $module_data . "_field` (`fieldid`, `fieldname`, `fieldalias`)VALUES (NULL, " . $db->quote( $get['name'] ) . ", " . $db->quote( $get['alias'] ) . ")"; 
        	if ( $db->insert_id( $query ) ){ 
            	 //$xxx->closeCursor();
            	 Header( "Location: " . $link_md); die();
        	} else { 
        	     $error = "Không thể lưu dữ liệu được"; 
        	} 
        }   
   }
}
if ($id != 0){
    $sql = $db->query("SELECT * FROM `" . NV_PREFIXLANG . "_" . $module_data."_field` WHERE `fieldid` = ". $id);
	while($row = $sql->fetch()){				
        $xtpl->assign('name', $row['fieldname'] );                
	}
}	
$xtpl->assign('error', $error );
if( $error!= '') $xtpl->parse('main.error'); 

$xtpl->parse('main');
$contents = $xtpl->text('main');

include (NV_ROOTDIR . "/includes/header.php");
echo nv_admin_theme($contents);
include (NV_ROOTDIR . "/includes/footer.php");
?>