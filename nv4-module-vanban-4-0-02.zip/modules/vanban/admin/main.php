<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */


if ( ! defined( 'NV_IS_LAWS_ADMIN' ) ) die( 'Stop!!!' );

if ( $nv_Request->isset_request( 'del', 'get' ) ){
    $id = $nv_Request->get_int( 'del', 'get', 0 );    
    if ( ! $id ) die( 'NO' );
    $sql = "DELETE FROM `" . NV_PREFIXLANG . "_" . $module_data . "` WHERE `id`=" . $id;
    $db->query( $sql );
	nv_del_moduleCache( $module_name );	
    die( 'OK' );
}

if ( $nv_Request->isset_request( 'chang_act', 'get,post' ) ){
    $id = $nv_Request->get_int('chang_act', 'post,get', 0);
    $act = $nv_Request->get_int('act', 'post,get', 0);
       
    $sql = "UPDATE  `" . NV_PREFIXLANG . "_" . $module_data ."` SET `active` = ".intval($act)."  WHERE `id`= ".$id;
    $result = $db->query( $sql );
    die('OK');
}

$per_page = 10;
$page = $nv_Request->get_int('page','post,get',1);
$base_url = NV_BASE_ADMINURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name . "&" . NV_OP_VARIABLE . "=main";


$search = array();
$search['q'] = $nv_Request->get_title('q','get,post','');
$search['cat'] = $nv_Request->get_int('cat','get,post',0);
$search['room'] = $nv_Request->get_int('room','get,post',0);
$search['field'] = $nv_Request->get_int('field','get,post',0);
$search['organ'] = $nv_Request->get_int('organ','get,post',0);
$search['ttime'] = $nv_Request->get_title('ttime','get,post','');
$search['dtime'] = $nv_Request->get_title('dtime','get,post','');

$where = '1=1';
if (!empty($search['q'])) {
    $where .= " AND (`name` LIKE '%" . $search['q'] . "%' OR `tomtat` LIKE '%" . $search['q'] . "%' OR `copyr` LIKE '%" . $search['q'] . "%')";
    $base_url.'&q='.$search['q'];
}
if ($search['cat'] > 0) {
    $where .= " AND `idcat` = " . $search['cat'];
    $base_url. "&cat=".$search['cat'];
}

if ($search['field'] > 0) {
    $where .= " AND `idfield` = " . $search['field'];
    $base_url. "&field=".$search['field'];
}
if ($search['room'] > 0) {
    $where .= " AND `idroom` = " . $search['room'];
    $base_url. "&room=".$search['room'];
}
if ($search['organ'] > 0) {
    $where .= " AND `idorgan` = " . $search['organ'];
    $base_url. "&organ=".$search['organ'];
}

$db->sqlreset()->from(NV_PREFIXLANG . "_" . $module_data)
    ->where($where);

//all_page
$db->select("COUNT(*)");
$all_page = $db->query($db->sql())->fetchColumn();

//rows
$db->select("*")
    ->order( "id DESC" )
    ->limit( $per_page )
    ->offset( ($page-1)*$per_page );
$array_data = $db->query($db->sql())->fetchAll();

$xtpl = new XTemplate("main.htm", NV_ROOTDIR . "/themes/" . $global_config['module_theme'] . "/modules/" . $module_name);
$xtpl->assign( 'NV_BASE_ADMINURL', NV_BASE_ADMINURL );
$xtpl->assign( 'NV_NAME_VARIABLE', NV_NAME_VARIABLE );
$xtpl->assign( 'NV_OP_VARIABLE', NV_OP_VARIABLE );
$xtpl->assign( 'MODULE_NAME', $module_name );
$xtpl->assign( 'OP', $op );
$xtpl->assign( 'SEARCH', $search );

$xtpl->assign('LINK_ADD', NV_BASE_ADMINURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name . "&" . NV_OP_VARIABLE . "=add");

unset($array_global_cat[0]);
unset($array_global_room[0]);
unset($array_global_field[0]);
unset($array_global_organ[0]);

foreach($array_global_cat as $array_global_cat1){  
    $array_global_cat1['selected'] = ($search['cat'] == $array_global_cat1['id'])? 'selected="selected"' : '';
    $xtpl->assign('cat', $array_global_cat1);     
    $xtpl->parse('main.cat');    
}
foreach($array_global_room as $array_global_room1){ 
    $array_global_room1['selected'] = ($search['room'] == $array_global_room1['id'])? 'selected="selected"' : '';
    $xtpl->assign('room', $array_global_room1);     
    $xtpl->parse('main.room');    
}
foreach($array_global_field as $array_global_field1){  
    $array_global_field1['selected'] = ($search['field'] == $array_global_field1['id'])? 'selected="selected"' : '';
    $xtpl->assign('field', $array_global_field1);     
    $xtpl->parse('main.field');    
}
foreach($array_global_organ as $array_global_organ1){  
    $array_global_organ1['selected'] = ($search['organ'] == $array_global_organ1['id'])? 'selected="selected"' : '';
    $xtpl->assign('organ', $array_global_organ1);     
    $xtpl->parse('main.organ');    
}

foreach( $array_data as $row ){    
        $row['cat_link'] = NV_BASE_ADMINURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name . "&" . NV_OP_VARIABLE . "=main&cat=".$row['idcat'];
        $row['room_link'] = NV_BASE_ADMINURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name . "&" . NV_OP_VARIABLE . "=main&room=".$row['idroom'];
        $row['field_link'] = NV_BASE_ADMINURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name . "&" . NV_OP_VARIABLE . "=main&field=".$row['idfield'];
        $row['organ_link'] = NV_BASE_ADMINURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name . "&" . NV_OP_VARIABLE . "=main&organ=".$row['idorgan'];
        $row['link_edit'] = NV_BASE_ADMINURL. "index.php?" . NV_NAME_VARIABLE . "=" . $module_name."&op=add&id=".$row['id'];
        $row['link_del'] = NV_BASE_ADMINURL. "index.php?" . NV_NAME_VARIABLE . "=" . $module_name."&del=".$row['id'];
        $row['link_view'] = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $module_name."&".NV_OP_VARIABLE."=".$module_info['alias']['view'].'/'.$row['alias']."-".$row['id'];
        $row['time'] = date( "d/m/Y", $row['time']);
        $row['cat'] = $array_global_cat[$row['idcat']];
        $row['room'] = $array_global_room[$row['idroom']];
        $row['field'] = $array_global_field[$row['idfield']];
        $row['organ'] = $array_global_organ[$row['idorgan']];            			
		$row['active_selected'] = ($row['active'] == 1 ) ?  'selected="selected"' : '';
        $xtpl->assign('ROW', $row);
		$xtpl->parse('main.loop');                
}
	
$generate_page = nv_generate_page($base_url, $all_page, $per_page, $page);
$xtpl->assign('GENERATE_PAGE', $generate_page);

$xtpl->parse('main');
$contents = $xtpl->text('main');


include (NV_ROOTDIR . "/includes/header.php");
echo nv_admin_theme($contents);
include (NV_ROOTDIR . "/includes/footer.php");
?>