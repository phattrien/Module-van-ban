<?php

/**
 * @Project NUKEVIET 4.x
 * @Author NhanhGon.vn (nhanhgon123@gmail.com))
 * @Copyright (C) 2014 NhanhGon.vn
 * @License GNU/GPL version 2 or any later version
 * @Createdate SUN, 16 June 2014 08:31:52 GMT
 */
 
if(!defined('NV_IS_LAWS_ADMIN')) { die('Stop!!!'); }

$result = false;
$id = $nv_Request->get_int('id', 'post,get', 0);

$sql = "SELECT active FROM `" . NV_PREFIXLANG . "_" . $module_data ."` WHERE `id`=" . $id;
$resuilt = $db->query( $sql );
$active = $result->fetchColumn();
$active = ($active == 1) ? 0 : 1; 

if( $id > 0 ){
   $sql = "UPDATE  `" . NV_PREFIXLANG . "_" . $module_data ."` SET `active` = $active  WHERE `id`= $id";
   $result = $db->query( $sql );
}
if( $result ){
   echo " Cập nhật thành công ";
}else{
   echo "Cập nhật thất bại ";
}
?>